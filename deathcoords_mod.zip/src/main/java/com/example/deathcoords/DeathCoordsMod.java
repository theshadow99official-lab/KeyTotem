package com.example.deathcoords;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.awt.datatransfer.StringSelection;
import java.awt.Toolkit;

public class DeathCoordsMod implements ModInitializer {

    private BlockPos lastDeathPos = null;

    @Override
    public void onInitialize() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof DeathScreen) {
                if (client.player != null) {
                    lastDeathPos = client.player.getLastDeathPos();
                }
                if (lastDeathPos != null) {
                    int x = lastDeathPos.getX();
                    int y = lastDeathPos.getY();
                    int z = lastDeathPos.getZ();

                    screen.addDrawableChild(new ButtonWidget(
                        scaledWidth / 2 - 100, 
                        scaledHeight / 2 + 40, 
                        200, 20, 
                        Text.literal("Copy Death Coordinates"),
                        button -> copyToClipboard(x, y, z)
                    ));
                }
            }
        });
    }

    private void copyToClipboard(int x, int y, int z) {
        String coords = String.format("X: %d, Y: %d, Z: %d", x, y, z);
        try {
            Toolkit.getDefaultToolkit()
                    .getSystemClipboard()
                    .setContents(new StringSelection(coords), null);
        } catch (Exception e) {
            MinecraftClient.getInstance().player.sendMessage(Text.literal("Failed to copy coordinates"), false);
            e.printStackTrace();
        }
    }
}